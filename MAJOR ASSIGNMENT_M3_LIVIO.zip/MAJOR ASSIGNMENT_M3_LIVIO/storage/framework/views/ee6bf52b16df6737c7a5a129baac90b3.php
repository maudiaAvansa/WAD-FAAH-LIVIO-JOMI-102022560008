<?php $__env->startSection('title', 'Data Pasien'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
        <div>
            <h2 class="fw-bold mb-1"><i class="bi bi-people"></i> Data Pasien</h2>
            <p class="text-muted mb-0">Modul 3 &mdash; data pasien dikelola dengan Laravel (MVC + Eloquent).</p>
        </div>
        <a href="<?php echo e(route('pasien.create')); ?>" class="btn btn-modul"><i class="bi bi-plus-lg"></i> Tambah Pasien</a>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card stat-card shadow-sm"><div class="card-body">
                <div class="text-muted small">Total Pasien</div>
                <div class="fs-3 fw-bold"><?php echo e($pasiens->count()); ?></div>
            </div></div>
        </div>
        <div class="col-md-4">
            <div class="card stat-card shadow-sm"><div class="card-body">
                <div class="text-muted small">Laki-laki</div>
                <div class="fs-3 fw-bold"><?php echo e($pasiens->where('jenis_kelamin', 'Laki-laki')->count()); ?></div>
            </div></div>
        </div>
        <div class="col-md-4">
            <div class="card stat-card shadow-sm"><div class="card-body">
                <div class="text-muted small">Perempuan</div>
                <div class="fs-3 fw-bold"><?php echo e($pasiens->where('jenis_kelamin', 'Perempuan')->count()); ?></div>
            </div></div>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-modul">
                        <tr>
                            <th>No</th>
                            <th>No. RM</th>
                            <th>Nama Pasien</th>
                            <th>L/P</th>
                            <th>Umur</th>
                            <th>Gol. Darah</th>
                            <th>No. HP</th>
                            <th>Domisili</th>
                            <th>Kontak Darurat</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $pasiens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><span class="badge badge-modul"><?php echo e($p->no_rm); ?></span></td>
                                <td>
                                    <div class="fw-semibold"><?php echo e($p->nama); ?></div>
                                    <div class="small text-muted">NIK: <?php echo e($p->nik ?: '-'); ?></div>
                                </td>
                                <td><?php echo e($p->jenis_kelamin === 'Laki-laki' ? 'L' : 'P'); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($p->tgl_lahir)->age); ?> th</td>
                                <td><?php echo e($p->gol_darah); ?></td>
                                <td><?php echo e($p->no_hp); ?></td>
                                <td>
                                    <div><?php echo e($p->alamat); ?></div>
                                    <div class="small text-muted"><?php echo e($p->kota); ?></div>
                                </td>
                                <td>
                                    <div><?php echo e($p->darurat_nama); ?> <span class="small text-muted">(<?php echo e($p->darurat_hubungan); ?>)</span></div>
                                    <div class="small text-muted"><?php echo e($p->darurat_hp); ?></div>
                                </td>
                                <td class="text-nowrap">
                                    <a href="<?php echo e(route('pasien.show', $p)); ?>" class="btn btn-sm btn-outline-secondary" title="Detail"><i class="bi bi-eye"></i></a>
                                    <a href="<?php echo e(route('pasien.edit', $p)); ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="bi bi-pencil"></i></a>
                                    <form action="<?php echo e(route('pasien.destroy', $p)); ?>" method="POST" class="d-inline"
                                          onsubmit="return confirm('Yakin hapus data pasien ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger" title="Hapus"><i class="bi bi-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="10" class="text-center text-muted py-4">Belum ada data pasien.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Livio Jomi F.M.Alves\OneDrive\Documents\GitHub\WAD-FAAH-LIVIO JOMI-102022560008\MAJOR ASSIGNMENT_M3_LIVIO\resources\views/pasien/index.blade.php ENDPATH**/ ?>