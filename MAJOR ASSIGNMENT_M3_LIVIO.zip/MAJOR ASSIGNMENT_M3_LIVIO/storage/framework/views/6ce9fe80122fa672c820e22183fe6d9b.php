<?php $__env->startSection('title', 'Tambah Pasien'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header mb-4">
        <h2 class="fw-bold mb-1"><i class="bi bi-person-vcard"></i> Form Pendaftaran Pasien</h2>
        <p class="text-muted mb-0">Isi data profil pasien, nomor rekam medis, domisili, dan kontak darurat.</p>
    </div>

    <form action="<?php echo e(route('pasien.store')); ?>" method="POST" class="card shadow-sm">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('pasien._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="card-footer bg-white d-flex justify-content-end gap-2 p-3">
            <a href="<?php echo e(route('pasien.index')); ?>" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Batal</a>
            <button type="submit" class="btn btn-modul"><i class="bi bi-save"></i> Simpan Pasien</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Livio Jomi F.M.Alves\modul-a-pasien\resources\views/pasien/create.blade.php ENDPATH**/ ?>